# /* coding: utf-8 */
# It is a easter egg of fateful Engine
# © simpleApps, 2010 - 2011

import os, sys
from Tkinter import *

os.chdir(os.path.dirname(sys.argv[0]))
sys.path.append("lib.zip")

import updater

def exit(___):
	os._exit(0)
 
def donate_me(event):
	root = Tk()
	lab = Label(root, text=u"Вы можете помочь развитию проекта, "\
			u"\nотправив произвольную сумму на кошелёк simpleApps:"\
			u"\nWMR: R309322481819\nWMZ: Z121265227264", font = "Garamond 14")
	but = Button(root)
	but["text"] = u"выход"
	but.bind("<Button-1>",exit)
	lab.pack(), but.pack()
	root.mainloop()

def get_eggs():
	updater.wget("http://simpleapps.ru/wtf.noext", "wtf")

def egg():
	root = Tk()
	but = Button(root)
	get_eggs()
	but["text"] = u"Donate | Пожертвовать"
	but.bind("<Button-1>",donate_me)
	image = PhotoImage(file = "wtf", master = root)
	label = Label(root, image = image)
	label.grid()
	root.images = image
	label.pack()
	but.pack()
	root.mainloop()
	
# Allons-y.
# None.