# /* encoding: utf-8 */
# Copyright sTools © simpleApps CodingTeam (Tue Oct 13 22:14:13 2011)
# This program published under GPL v3 license
# See LICENSE.GPL for more details

## ZLIB.
def ZLIBEncoder(__x__):
	try:
		if type(__x__) != str:
			return type(__x__)(repr(x.encode("zlib")) for x in __x__)
		return repr(__x__.encode("zlib"))
	except:
		crashlog("ZLIBEncoder")
		return __x__
		
def ZLIBDecoder(__x__):
	try:
		if type(__x__) != str:
			return type(__x__)(repr(x.decode("zlib")) for x in __x__)
		return repr(__x__.decode("zlib"))
	except:
		crashlog("ZLIBDecoder")
		return __x__

# OS.
def getArchitecture():
	from struct import calcsize
	is_amd64 = (calcsize("P") is 8)
	if is_amd64:
		return "[amd64]"
	elif calcsize("P") != 4:
		from platform import processor
		return processor()
	return "[i386]"

def ntDetect():
	try:
		from os import popen
		pipe = popen("ver")
		osMain = pipe.read()
		try: osMain = osMain.decode("cp866")
		except: pass
		pipe.close()
	except:
		crashlog("ntDetect")
		osMain = "NT"
	del popen
	return osMain

## Conference Encoder.
from string import digits, ascii_letters

__exceptions = "-/.@_"
ascii_tab = tuple(digits + ascii_letters + __exceptions)

def chkFile(filename):
	if filename.count("/") > 1:
		if not chkUnicode(filename):
			filename = nameEncode(filename)
	return filename

def chkUnicode(body):
	for symbol in body:
		if symbol not in ascii_tab:
			return False
	return True

def nameEncode(filename):
	from base64 import b16encode
	encodedName = str()
	for name in filename.split("/"):
		if name.count("."):
			if name.count("@"):
				_list = name.split("@", 1)
				chatname = b16encode(_list[0].encode("utf-8"))
				encodedName += "%s@%s/" % (chatname[(len(chatname) / 2):].decode("utf-8"), _list[1])
			else:
				encodedName += name
		else:
			encodedName += u"%s/" % (name)
	del b16encode
	return encodedName
	
del digits, ascii_letters