# /* encoding: utf-8 */
# © simpleApps, 2010 - 2011

# imports for working.

from sys import stdout
def Print(text, system = None):
    if not system:
        try: print text
        except: pass
    else:
        try: print u"#-# engine:", text
        except: pass

def printer(text):
	try: stdout.write(text); stdout.flush()
	except: pass
 
def fiXme(msg):
	Print("#! fiXme: \"%s\"." % msg) 

def exc_print(limit = None, _file = None):
	from traceback import print_exc
	try:
		if not _file:
			print_exc()
		else:
			print_exc(limit, _file)
	except:
		print_exc()
	del print_exc
	
def Wait(xdict, who, _time = 1):
	from threading import Thread
	Thread(None, subWait, subWait, (xdict, who, _time)).start()
	del Thread
	return True

def subWait(xdict, who, time):
	from time import sleep
	while not xdict[who]:
		printer(".")
		sleep(time)
	print;
	del sleep
	return True