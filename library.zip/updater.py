# /* encoding: utf-8 */
# © simpleApps, 2010 - 2011

# This module can:
#	* extract files from ZIP (not tested on NT systems).
#	* download files from WWW.

from writer import *

def unZIP(filename):
	from zipfile import ZipFile
	num = int()
	ZIP = ZipFile(filename)
	for name in ZIP.namelist():
		printer("\n[%s] extracting \"%s\": " % (`unZIP`, name))
		ZIP.extract(name)
		printer("ok.")
		num += 1
	ZIP.close()
	Print("\n[%s] extracted %i files." % (`unZIP`, num))
	del ZipFile
	return num

def wget(url, filename):
	from urllib import urlretrieve
	from os.path import exists
	from os import remove
	if exists(filename):
		remove(filename)
	try:
		printer("#-# engine: Downloading: %s." % filename)
		xdict = dict()
		xdict["wget"] = False
		Wait(xdict, "wget", 0.6)
		urlretrieve(url, filename)
		xdict["wget"] = True
		del xdict
	except:
		Print("Download error: \n", True)
		exc_print()
		return False
	del urlretrieve, exists, remove
	Print("Downloaded.",True)

# Allons-y.